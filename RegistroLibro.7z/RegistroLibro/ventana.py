from tkinter import *
from tkinter import ttk
from libros import *
from tkinter import messagebox


class Ventana(Frame):
    
    paises = Libros()
        
    def __init__(self, master=None):
        super().__init__(master,width=680, height=260)
        self.master = master
        self.pack()
        self.create_widgets()
        self.llenaDatos()
        self.habilitarCajas("disabled")  
        self.habilitarBtnOper("normal")
        self.habilitarBtnGuardar("disabled")  
        self.id=-1      
# Habilitar Cajas (Atraves de boton Registro)             
    def habilitarCajas(self,estado):
        self.txtCodigo.configure(state=estado)
        self.txtCapital.configure(state=estado)
        self.txtEditorial.configure(state=estado)
        self.txtTitulo.configure(state=estado)
        
    def habilitarBtnOper(self,estado):
        self.btnNuevo.configure(state=estado)                
        
# Habilitar boton Guardar (Atraves de boton Registro)     
    def habilitarBtnGuardar(self,estado):
        self.btnGuardar.configure(state=estado)                
        self.btnCancelar.configure(state=estado)                

# Limpiar Cajas
    def limpiarCajas(self):
        self.txtCapital.delete(0,END)
        self.txtEditorial.delete(0,END)
        self.txtCodigo.delete(0,END)
        self.txtTitulo.delete(0,END)          
# Llenar datos en Grid
    def llenaDatos(self):
        datos = self.paises.consulta_paises()        
        for row in datos:            
            self.grid.insert("",END,text=row[0], values=(row[1],row[2], row[3],row[4]))
        if len(self.grid.get_children()) > 0:
            self.grid.selection_set( self.grid.get_children()[0] )  
# Boton Registrar
    def fNuevo(self):         
        self.habilitarCajas("normal")  
        self.habilitarBtnOper("disabled")
        self.habilitarBtnGuardar("normal")
        self.limpiarCajas()        
        self.txtCodigo.focus()
# Boton Guardar
    def fGuardar(self): 
        if self.id ==-1:       
            self.paises.inserta_pais(self.txtCodigo.get(),self.txtTitulo.get(),self.txtCapital.get(),self.txtEditorial.get())            
            messagebox.showinfo("REGISTRAR", 'Datos Insertados correctamente.')
        else:
            self.paises.modifica_pais(self.id,self.txtCodigo.get(),self.txtTitulo.get(),self.txtCapital.get(),self.txtEditorial.get())
            messagebox.showinfo("Modificar", 'Elemento modificado correctamente.')
            self.id = -1            
        self.llenaDatos() 
        self.limpiarCajas() 
        self.habilitarBtnGuardar("disabled")      
        self.habilitarBtnOper("normal")
        self.habilitarCajas("disabled")
# Boton Cancelar              
    def fCancelar(self):
        r = messagebox.askquestion("CANCELAR", "¿Esta seguro que desea cancelar el Registro?")
        if r == messagebox.YES:
            self.limpiarCajas() 
            self.habilitarBtnGuardar("disabled")      
            self.habilitarBtnOper("normal")
            self.habilitarCajas("disabled")
    def create_widgets(self):
# Marco para Botones (frame1) 
        frame1 = Frame(self, bg="#bfdaff")
        frame1.place(x=0,y=0,width=93, height=259)
# Boton Registrar Libro
        self.btnNuevo=Button(frame1,text="REGISTRAR", command=self.fNuevo, bg="#32C2A8", fg="white")       
        self.btnNuevo.place(x=5,y=50,width=80, height=30 )
# Marco para cajas de textos (frame2)
        frame2 = Frame(self,bg="#d3dde3" )
        frame2.place(x=95,y=0,width=150, height=259)
        
# Marco Registrar Datos Libro
        lbl1 = Label(frame2,text="CODIGO: ")
        lbl1.place(x=3,y=5)        
        self.txtCodigo=Entry(frame2)
        self.txtCodigo.place(x=3,y=25,width=150, height=20)
        
        lbl2 = Label(frame2,text="TITULO: ")
        lbl2.place(x=3,y=55)        
        self.txtTitulo=Entry(frame2)
        self.txtTitulo.place(x=3,y=75,width=150, height=20)
        
        lbl3 = Label(frame2,text="EDITORIAL: ")
        lbl3.place(x=3,y=105)        
        self.txtCapital=Entry(frame2)
        self.txtCapital.place(x=3,y=125,width=150, height=20)
        
        lbl4 = Label(frame2,text="AUTOR 1: ")
        lbl4.place(x=3,y=155)        
        self.txtEditorial=Entry(frame2)
        self.txtEditorial.place(x=3,y=175,width=150, height=20)
        
# Boton Guardar datos Libro
        self.btnGuardar=Button(frame2,text="GUARDAR", command=self.fGuardar, bg="#32C2A8", fg="white")
        self.btnGuardar.place(x=10,y=210,width=65, height=30)
# Boton Cancelar datos Libro
        self.btnCancelar=Button(frame2,text="CANCELAR", command=self.fCancelar, bg="#32C2A8", fg="white")
        self.btnCancelar.place(x=80,y=210,width=65, height=30)
# Marco para Botones (frame3)
        frame3 = Frame(self,bg="yellow" )
        frame3.place(x=247,y=0,width=420, height=259)
# Marco Tabla de Registro libro
        self.grid = ttk.Treeview(frame3, columns=("col1","col2","col3","col4"))
        self.grid.column("#0",width=60)
        # Configuracion Titulos columnas  
        self.grid.column("col1",width=70, anchor=CENTER)
        self.grid.column("col2",width=90, anchor=CENTER)
        self.grid.column("col3",width=90, anchor=CENTER)
        self.grid.column("col4",width=90, anchor=CENTER)
        # Configuracion columnas
        self.grid.heading("#0", text="ID", anchor=CENTER)
        self.grid.heading("col1", text="CODIGO", anchor=CENTER)
        self.grid.heading("col2", text="TITULO", anchor=CENTER)
        self.grid.heading("col3", text="EDITORIAL", anchor=CENTER)
        self.grid.heading("col4", text="AUTOR 1", anchor=CENTER)
        
        self.grid.pack(side=LEFT,fill = Y)
# Barra de desplazamiento Vertical
        sb = Scrollbar(frame3, orient=VERTICAL)
        sb.pack(side=RIGHT, fill = Y)
        self.grid.config(yscrollcommand=sb.set)
        sb.config(command=self.grid.yview)
        self.grid['selectmode']='browse'

